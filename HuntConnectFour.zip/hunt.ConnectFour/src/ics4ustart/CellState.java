package ics4ustart;

/**
 * Defined state for each cell in the Board.
 * @author Hutchison
 * @version 1.0
 */
public enum CellState {
	EMPTY, P1, P2
}
